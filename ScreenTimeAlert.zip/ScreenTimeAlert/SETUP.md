# Screen Time Alert: setup

## Build the app (one time)
1. Install Android Studio on your computer: https://developer.android.com/studio
2. Unzip this project. In Android Studio choose File > Open and pick the ScreenTimeAlert folder.
3. Wait for "Gradle sync" to finish (first time takes a few minutes and needs internet).
4. On your phone: Settings > About phone > tap "Build number" 7 times, then
   Settings > Developer options > turn on USB debugging.
5. Connect the phone with a USB cable and allow the prompt on the phone.
6. Click the green Run button in Android Studio. The app installs on your phone.

## Use it
1. Open Screen Time Alert and allow notifications.
2. Set your limits (minutes in a row, and minutes per day).
3. Tap "Start monitoring".
4. Tap "Allow background running" and set the app to Unrestricted so Android does not stop it.

It counts the time your screen is on. A break of 5 minutes with the screen off starts a new session.
