package com.example.screentimealert

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED &&
            Prefs.get(context).getBoolean(Prefs.ENABLED, false)
        ) {
            try {
                MonitorService.start(context)
            } catch (e: Exception) {
                // Android may refuse to start it at boot; opening the app starts it again.
            }
        }
    }
}
