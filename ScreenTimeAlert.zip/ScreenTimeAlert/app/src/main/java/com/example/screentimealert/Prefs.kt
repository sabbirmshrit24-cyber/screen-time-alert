package com.example.screentimealert

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val NAME = "screen_time_alert"

    const val ENABLED = "enabled"
    const val SESSION_LIMIT_MIN = "session_limit_min"
    const val DAILY_LIMIT_MIN = "daily_limit_min"
    const val DAY = "day"
    const val DAILY_MS = "daily_ms"
    const val SESSION_MS = "session_ms"
    const val SESSION_ALERTS = "session_alerts"
    const val DAILY_ALERTED = "daily_alerted"
    const val LAST_ACTIVE = "last_active"

    const val DEFAULT_SESSION_MIN = 30
    const val DEFAULT_DAILY_MIN = 180

    fun get(context: Context): SharedPreferences =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
}
