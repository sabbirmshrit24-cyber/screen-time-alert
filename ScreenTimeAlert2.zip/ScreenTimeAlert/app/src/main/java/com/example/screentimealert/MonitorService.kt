package com.example.screentimealert

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Runs in the background, counts how long the screen is on,
 * and rings + vibrates for 20 seconds when you go over your limits.
 */
class MonitorService : Service() {

    companion object {
        private const val MONITOR_CHANNEL = "monitor"
        private const val ALERT_CHANNEL = "alerts2"
        private const val ACTION_STOP_ALERT = "com.example.screentimealert.STOP_ALERT"
        private const val TICK_MS = 15_000L           // how often we count
        private const val BREAK_MS = 5 * 60_000L      // screen off this long = a real break
        private const val REMIND_MS = 10 * 60_000L    // remind again every 10 min after the limit
        private const val ALERT_MS = 20_000L          // how long the alert rings and vibrates

        @Volatile
        private var instance: MonitorService? = null

        fun start(context: Context) {
            context.startForegroundService(Intent(context, MonitorService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, MonitorService::class.java))
        }

        /** Called when you open the app: silences a ringing alert. */
        fun stopAlertNow() {
            instance?.stopAlert()
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private var lastTick = 0L
    private var screenOn = false
    private var ringtone: Ringtone? = null

    private val stopAlertRunnable = Runnable { stopAlert() }

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, TICK_MS)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_ON -> onScreenOn()
                Intent.ACTION_SCREEN_OFF -> onScreenOff()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs.get(this)
        createChannels()

        val notification = buildMonitorNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        registerReceiver(screenReceiver, filter)

        val now = System.currentTimeMillis()
        if (now - prefs.getLong(Prefs.LAST_ACTIVE, 0L) > BREAK_MS) resetSession()

        val pm = getSystemService(PowerManager::class.java)
        if (pm.isInteractive) startCounting()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_ALERT) stopAlert()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        stopAlert()
        instance = null
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
            // already unregistered
        }
        super.onDestroy()
    }

    // ---- screen state ----

    private fun onScreenOn() {
        val now = System.currentTimeMillis()
        if (now - prefs.getLong(Prefs.LAST_ACTIVE, 0L) > BREAK_MS) resetSession()
        startCounting()
    }

    private fun onScreenOff() {
        if (screenOn) tick()
        screenOn = false
        handler.removeCallbacks(ticker)
        stopAlert() // you locked the phone, so the break has started
        prefs.edit().putLong(Prefs.LAST_ACTIVE, System.currentTimeMillis()).apply()
    }

    private fun startCounting() {
        screenOn = true
        lastTick = System.currentTimeMillis()
        handler.removeCallbacks(ticker)
        handler.postDelayed(ticker, TICK_MS)
    }

    private fun resetSession() {
        prefs.edit()
            .putLong(Prefs.SESSION_MS, 0L)
            .putInt(Prefs.SESSION_ALERTS, 0)
            .apply()
    }

    // ---- counting ----

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun rollDayIfNeeded() {
        val t = today()
        if (prefs.getString(Prefs.DAY, "") != t) {
            prefs.edit()
                .putString(Prefs.DAY, t)
                .putLong(Prefs.DAILY_MS, 0L)
                .putBoolean(Prefs.DAILY_ALERTED, false)
                .apply()
        }
    }

    private fun tick() {
        val now = System.currentTimeMillis()
        rollDayIfNeeded()
        val delta = (now - lastTick).coerceAtLeast(0L)
        lastTick = now

        val daily = prefs.getLong(Prefs.DAILY_MS, 0L) + delta
        val session = prefs.getLong(Prefs.SESSION_MS, 0L) + delta
        prefs.edit()
            .putLong(Prefs.DAILY_MS, daily)
            .putLong(Prefs.SESSION_MS, session)
            .putLong(Prefs.LAST_ACTIVE, now)
            .apply()

        checkAlerts(daily, session)
    }

    private fun checkAlerts(daily: Long, session: Long) {
        val sessionLimit = prefs.getInt(Prefs.SESSION_LIMIT_MIN, Prefs.DEFAULT_SESSION_MIN) * 60_000L
        val dailyLimit = prefs.getInt(Prefs.DAILY_LIMIT_MIN, Prefs.DEFAULT_DAILY_MIN) * 60_000L

        val count = prefs.getInt(Prefs.SESSION_ALERTS, 0)
        if (sessionLimit > 0 && session >= sessionLimit + count * REMIND_MS) {
            prefs.edit().putInt(Prefs.SESSION_ALERTS, count + 1).apply()
            sendAlert(
                2,
                "Time for a break",
                "You have been on your phone for ${session / 60_000} minutes in a row."
            )
        }

        if (dailyLimit > 0 && daily >= dailyLimit && !prefs.getBoolean(Prefs.DAILY_ALERTED, false)) {
            prefs.edit().putBoolean(Prefs.DAILY_ALERTED, true).apply()
            sendAlert(
                3,
                "Daily limit reached",
                "You have used your phone for ${daily / 60_000} minutes today."
            )
        }
    }

    // ---- ring + vibrate for 20 seconds ----

    private fun startAlert() {
        stopAlert()

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val r = RingtoneManager.getRingtone(this, uri)
            if (r != null) {
                r.setAudioAttributes(attrs)
                if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
                r.play()
                ringtone = r
            }
        } catch (e: Exception) {
            // no sound available
        }

        try {
            val vibrator = getSystemService(Vibrator::class.java)
            vibrator?.vibrate(
                VibrationEffect.createWaveform(longArrayOf(0, 600, 400), 0),
                attrs
            )
        } catch (e: Exception) {
            // no vibrator available
        }

        handler.postDelayed(stopAlertRunnable, ALERT_MS)
    }

    private fun stopAlert() {
        handler.removeCallbacks(stopAlertRunnable)
        try {
            ringtone?.stop()
        } catch (e: Exception) {
            // ignore
        }
        ringtone = null
        try {
            getSystemService(Vibrator::class.java)?.cancel()
        } catch (e: Exception) {
            // ignore
        }
    }

    // ---- notifications ----

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)

        nm.createNotificationChannel(
            NotificationChannel(
                MONITOR_CHANNEL,
                "Background monitoring",
                NotificationManager.IMPORTANCE_LOW
            )
        )

        // The old alert channel made only a short buzz. Replace it with a silent one;
        // the sound and vibration now come from startAlert().
        nm.deleteNotificationChannel("alerts")
        val alerts = NotificationChannel(
            ALERT_CHANNEL,
            "Screen time alerts",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            enableVibration(false)
            setSound(null, null)
        }
        nm.createNotificationChannel(alerts)
    }

    private fun openAppIntent(): PendingIntent =
        PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

    private fun stopAlertIntent(): PendingIntent =
        PendingIntent.getService(
            this,
            1,
            Intent(this, MonitorService::class.java).setAction(ACTION_STOP_ALERT),
            PendingIntent.FLAG_IMMUTABLE
        )

    private fun buildMonitorNotification(): Notification =
        Notification.Builder(this, MONITOR_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Screen Time Alert")
            .setContentText("Watching your screen time")
            .setOngoing(true)
            .setContentIntent(openAppIntent())
            .build()

    private fun sendAlert(id: Int, title: String, text: String) {
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_pause),
            "Stop",
            stopAlertIntent()
        ).build()

        val notification = Notification.Builder(this, ALERT_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .setDeleteIntent(stopAlertIntent())
            .addAction(stopAction)
            .build()
        getSystemService(NotificationManager::class.java).notify(id, notification)

        startAlert()
    }
}
