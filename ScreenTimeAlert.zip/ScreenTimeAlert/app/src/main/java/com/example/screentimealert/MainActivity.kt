package com.example.screentimealert

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var statusText: TextView
    private lateinit var sessionInput: EditText
    private lateinit var dailyInput: EditText
    private lateinit var toggleButton: Button

    private val refresher = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 2000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        sessionInput = findViewById(R.id.sessionInput)
        dailyInput = findViewById(R.id.dailyInput)
        toggleButton = findViewById(R.id.toggleButton)

        val prefs = Prefs.get(this)
        sessionInput.setText(
            prefs.getInt(Prefs.SESSION_LIMIT_MIN, Prefs.DEFAULT_SESSION_MIN).toString()
        )
        dailyInput.setText(
            prefs.getInt(Prefs.DAILY_LIMIT_MIN, Prefs.DEFAULT_DAILY_MIN).toString()
        )

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            saveLimits()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        toggleButton.setOnClickListener { toggleMonitoring() }

        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        askNotificationPermission()
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresher)
    }

    override fun onPause() {
        handler.removeCallbacks(refresher)
        super.onPause()
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun saveLimits() {
        val session = (sessionInput.text.toString().toIntOrNull() ?: Prefs.DEFAULT_SESSION_MIN)
            .coerceIn(0, 1440)
        val daily = (dailyInput.text.toString().toIntOrNull() ?: Prefs.DEFAULT_DAILY_MIN)
            .coerceIn(0, 1440)
        Prefs.get(this).edit()
            .putInt(Prefs.SESSION_LIMIT_MIN, session)
            .putInt(Prefs.DAILY_LIMIT_MIN, daily)
            .apply()
        sessionInput.setText(session.toString())
        dailyInput.setText(daily.toString())
    }

    private fun toggleMonitoring() {
        saveLimits()
        val prefs = Prefs.get(this)
        if (prefs.getBoolean(Prefs.ENABLED, false)) {
            MonitorService.stop(this)
            prefs.edit().putBoolean(Prefs.ENABLED, false).apply()
        } else {
            askNotificationPermission()
            MonitorService.start(this)
            prefs.edit().putBoolean(Prefs.ENABLED, true).apply()
        }
        refresh()
    }

    private fun formatTime(ms: Long): String {
        val minutes = ms / 60_000L
        return if (minutes >= 60) "${minutes / 60}h ${minutes % 60}m" else "${minutes}m"
    }

    private fun refresh() {
        val prefs = Prefs.get(this)
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val daily = if (prefs.getString(Prefs.DAY, "") == today) prefs.getLong(Prefs.DAILY_MS, 0L) else 0L
        val session = prefs.getLong(Prefs.SESSION_MS, 0L)
        val running = prefs.getBoolean(Prefs.ENABLED, false)

        statusText.text = "Today: ${formatTime(daily)}\n" +
            "This session: ${formatTime(session)}\n" +
            "Status: ${if (running) "Running" else "Stopped"}"
        toggleButton.text = if (running) "Stop monitoring" else "Start monitoring"
    }
}
